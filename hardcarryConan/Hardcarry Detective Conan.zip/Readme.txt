
Window API (C++) 로 제작한 명탐정 코난 테마 쓰리매치게임입니다.
Window API（C++)で作った名探偵コナンテーマのマッチ3ゲームです。

* 제작자 : 송인애 (잠자는 파인애용)
* 製作者 : Sleeping Pinaeong

* 제작기간 : 1개월
* 製作期間：一ヵ月

* Sound File Source from...
 - Combo sounds : Anipang
 - BGM : Detective Conan animation OST

* Image File Source from...
 - Title Logo : made by Pinaeong
 - Title Charactor : Detective conan Gameboy
 - Block : made by Pinaeong
 - Top Side Running Conan : made by Pinaeong
 - BG, Attack objects : Detective Conan mobile Game


https://github.com/Song-In-Love/pinaeongs-portfolios/
pinaeong@gmail.com
